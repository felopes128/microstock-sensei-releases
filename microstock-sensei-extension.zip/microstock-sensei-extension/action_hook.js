




(() => {
  const hook = (g) => {
    if (!g || !g.enterprise || g.enterprise.__senseiActionHook) return false;
    const orig = g.enterprise.execute;
    if (typeof orig !== "function") return false;
    g.enterprise.execute = function (key, opts) {
      try {
        const a = (opts && opts.action) || "";
        if (a) window.postMessage({ from: "sensei-action", action: a, siteKey: key || "" }, "*");
      } catch (e) {}
      return orig.apply(this, arguments);
    };
    g.enterprise.__senseiActionHook = true;
    return true;
  };
  if (window.grecaptcha && hook(window.grecaptcha)) return;
  
  let _g = window.grecaptcha;
  try {
    Object.defineProperty(window, "grecaptcha", {
      configurable: true,
      get() { return _g; },
      set(v) { _g = v; try { hook(v); } catch (e) {} },
    });
  } catch (e) {}
  let n = 0;
  const iv = setInterval(() => {
    if ((window.grecaptcha && hook(window.grecaptcha)) || ++n > 160) clearInterval(iv);
  }, 250);
})();
