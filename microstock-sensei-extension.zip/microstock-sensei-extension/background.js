



const BRIDGE = "http://127.0.0.1:17654";
const TICK_MIN = 0.25;                 
const LOGIN_COOKIES = ["SAPISID", "__Secure-1PSID", "__Secure-3PSID"];

let _token = null;                     
let _extId = null;                     
let _tokenCount = 0;                   
let _lastMintAt = 0;                   


async function getExtId() {
  if (_extId) return _extId;
  const d = await chrome.storage.local.get(["extId"]);
  if (d.extId) { _extId = d.extId; return _extId; }
  _extId = (crypto.randomUUID && crypto.randomUUID()) ||
           (Date.now().toString(36) + "-" + Math.random().toString(36).slice(2));
  await chrome.storage.local.set({ extId: _extId });
  return _extId;
}
async function getToken() {
  if (_token) return _token;
  const d = await chrome.storage.local.get(["token"]);
  _token = d.token || null;
  return _token;
}


chrome.runtime.onInstalled.addListener(() => { ensureAlarms(); pump(); });
chrome.runtime.onStartup.addListener(() => { ensureAlarms(); pump(); });
function ensureAlarms() {
  chrome.alarms.create("tick", { periodInMinutes: TICK_MIN });
}
chrome.alarms.onAlarm.addListener((a) => { if (a.name === "tick") pump().catch(() => {}); });


setTimeout(() => pump().catch(() => {}), 0);


async function isLoggedIn() {
  for (const name of LOGIN_COOKIES) {
    try {
      const c = await chrome.cookies.get({ url: "https://google.com", name });
      if (c && c.value && c.value.length > 10) return true;
    } catch (e) {}
  }
  return false;
}


async function detectAccount() {
  try {
    const tab = await findFlowTab();
    if (!tab) return "";
    const res = await chrome.scripting.executeScript({
      target: { tabId: tab.id }, world: "MAIN",
      func: () => {
        const RE = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i;
        
        const sels = ["a[aria-label*='Google Account']", "a[aria-label*='Conta do Google']",
                      "img[alt*='@']", "[aria-label*='@']"];
        for (const s of sels) {
          const el = document.querySelector(s);
          if (el) {
            const v = (el.getAttribute("aria-label") || "") + " " + (el.getAttribute("alt") || "");
            const m = v.match(RE);
            if (m) return m[0];
          }
        }
        
        const m = document.documentElement.innerHTML.match(RE);
        return m ? m[0] : "";
      },
    });
    return (res && res[0] && res[0].result) || "";
  } catch (e) { return ""; }
}


async function bridgeUp() {
  try {
    const r = await fetch(`${BRIDGE}/status`, { signal: AbortSignal.timeout(3000) });
    return r.ok;
  } catch (e) { return false; }
}



async function ensureConnected() {
  if (await getToken()) return true;
  const extId = await getExtId();
  const loggedIn = await isLoggedIn();
  const label = (loggedIn && await detectAccount()) || "Chrome";
  try {
    const r = await fetch(`${BRIDGE}/hello`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ extId, label }),
      signal: AbortSignal.timeout(5000),
    });
    if (!r.ok) return false;
    const j = await r.json();
    _token = j.token;
    await chrome.storage.local.set({ token: _token });
    return true;
  } catch (e) { return false; }                    
}

const _sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let _pumping = false;
let _pumpN = 0;




async function pump() {
  if (_pumping) return;
  _pumping = true;
  let idle = 0;
  try {
    while (true) {
      const connected = await ensureConnected();
      if (connected) {
        idle = 0;
        const token = await getToken();
        await pollOnce(token);                       
        if (_pumpN++ % 10 === 0) {                    
          const loggedIn = await isLoggedIn();
          await reportCookies(token, loggedIn ? await detectAccount() : "", loggedIn);
          keepFlowWarm().catch(() => {});
        }
        await _sleep(1500);
      } else {
        if (++idle >= 3) break;                       
        await _sleep(3000);
      }
    }
  } finally { _pumping = false; }
}

async function pollOnce(token) {
  if (!token) return;
  try {
    const r = await fetch(`${BRIDGE}/poll`, {
      headers: { "Authorization": `Bearer ${token}` },
      signal: AbortSignal.timeout(5000),
    });
    if (r.status === 401) { _token = null; await chrome.storage.local.remove("token"); return; }
    if (r.ok) { const j = await r.json(); if (j.task) await handleTask(token, j.task); }
  } catch (e) {}
}

async function reportCookies(token, account, loggedIn) {
  let cookies = [];
  try {
    const a = await chrome.cookies.getAll({ domain: "google.com" });
    const b = await chrome.cookies.getAll({ domain: "labs.google" });
    cookies = [...a, ...b].map(c => ({
      name: c.name, value: c.value, domain: c.domain, path: c.path,
      secure: c.secure, httpOnly: c.httpOnly, sameSite: c.sameSite,
      expirationDate: c.expirationDate,
    }));
  } catch (e) {}
  try {
    await fetch(`${BRIDGE}/cookies`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
      body: JSON.stringify({ account, loggedIn, cookies }),
      signal: AbortSignal.timeout(5000),
    });
  } catch (e) {}
}

async function handleTask(token, task) {
  if (task.kind === "mint_recaptcha") { await mintRecaptcha(token, task); return; }
  if (task.kind === "flow_generate") { await runFlowGen(token, task); return; }
  await postResult(token, task.id, "ack", { kind: task.kind || "" });  
}




async function mintRecaptcha(token, task) {
  let tab = await findFlowTab();
  if (!tab) tab = await openFlowTab();
  if (!tab || !tab.id) { await postResult(token, task.id, "error", { message: "Sem aba do Flow" }); return; }
  
  let action = task.action || "";
  if (!action) {
    try { const d = await chrome.storage.local.get(["flowAction"]); action = d.flowAction || ""; } catch (e) {}
  }
  try {
    const res = await chrome.scripting.executeScript({
      target: { tabId: tab.id }, world: "MAIN",
      func: async (siteKeyParam, actionParam) => {
        try {
          if (typeof grecaptcha === "undefined" || !grecaptcha.enterprise)
            return { token: null, error: "grecaptcha enterprise não está pronto" };
          let key = siteKeyParam;
          if (!key) {                                  
            try {
              if (typeof ___grecaptcha_cfg !== "undefined" && ___grecaptcha_cfg.clients) {
                const clients = ___grecaptcha_cfg.clients;
                for (const id in clients) {
                  const c = clients[id];
                  for (const p of Object.keys(c)) {
                    const v = c[p];
                    if (v && typeof v === "object") {
                      for (const p2 of Object.keys(v)) {
                        const v2 = v[p2];
                        if (v2 && typeof v2 === "object" && v2.sitekey) { key = v2.sitekey; break; }
                      }
                    }
                    if (key) break;
                  }
                  if (key) break;
                }
              }
              if (!key) {
                const s = document.querySelector('script[src*="recaptcha"]');
                const m = s && s.src.match(/[?&]render=([^&]+)/);
                if (m && m[1] !== "explicit") key = m[1];
              }
            } catch (e) {}
          }
          if (!key) return { token: null, error: "sitekey não encontrada na página" };
          await new Promise((r) => grecaptcha.enterprise.ready(r));
          const t = await Promise.race([
            grecaptcha.enterprise.execute(key, { action: actionParam || "" }),
            new Promise((_, rej) => setTimeout(() => rej(new Error("execute timeout")), 15000)),
          ]);
          return { token: t, siteKey: key, error: null };
        } catch (e) { return { token: null, error: String((e && e.message) || e) }; }
      },
      args: [task.siteKey || "", action],
    });
    const out = (res && res[0] && res[0].result) || { token: null, error: "sem resultado" };
    if (out) out.action = action;          
    if (out && out.token) {                
      const wasIdle = (Date.now() - _lastMintAt) > 25000;
      _tokenCount++; _lastMintAt = Date.now();
      if (wasIdle && tab && tab.id) {      
        try { chrome.tabs.update(tab.id, { active: true }); } catch (e) {}
        try { if (tab.windowId != null) chrome.windows.update(tab.windowId, { focused: true }); } catch (e) {}
      }
    }
    await postResult(token, task.id, out.token ? "token" : "error", out);
  } catch (e) {
    await postResult(token, task.id, "error", { message: "executeScript: " + String(e) });
  }
}

async function postResult(token, taskId, event, data) {
  try {
    await fetch(`${BRIDGE}/result`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
      body: JSON.stringify({ taskId: taskId || "", event, data: data || {} }),
      signal: AbortSignal.timeout(8000),
    });
  } catch (e) {}
}

async function openFlowTab() {
  try {
    const tab = await chrome.tabs.create({ url: "https://labs.google/fx/tools/flow", active: false });
    await new Promise((resolve) => {
      const l = (id, info) => {
        if (id === tab.id && info.status === "complete") { chrome.tabs.onUpdated.removeListener(l); resolve(); }
      };
      chrome.tabs.onUpdated.addListener(l);
      setTimeout(() => { chrome.tabs.onUpdated.removeListener(l); resolve(); }, 20000);
    });
    return tab;
  } catch (e) { return null; }
}




async function runFlowGen(token, task) {
  let tab = await findFlowTab();
  if (!tab) tab = await openFlowTab();
  if (!tab || !tab.id) { await postResult(token, task.id, "error", { message: "Sem aba do Flow" }); return; }
  try { await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch (e) {}
  const spec = {
    taskId: task.id || "", prompt: task.prompt || "", aspect: task.aspect || "",
    perGen: task.perGen || "1x", model: task.model || "", quality: task.quality || "1K",
    timeoutMs: Math.max(30000, Number(task.timeoutMs) || 180000),
  };
  try {
    
    await chrome.scripting.executeScript({
      target: { tabId: tab.id }, world: "MAIN",
      func: (s) => { window.__senseiFlowSpec = s; }, args: [spec],
    });
    
    await chrome.scripting.executeScript({
      target: { tabId: tab.id }, world: "MAIN", files: ["flow_gen.js"],
    });
  } catch (e) {
    await postResult(token, task.id, "error", { message: "injeção falhou: " + String(e) });
  }
}


async function findFlowTab() {
  try {
    const tabs = await chrome.tabs.query({});
    const flow = tabs.filter(t => t.url && t.url.includes("labs.google"));
    flow.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
    return flow[0] || null;
  } catch (e) { return null; }
}
async function keepFlowWarm() {
  const tab = await findFlowTab();
  if (!tab) return;
  try { await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch (e) {}
  
}


chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  
  if (msg && msg.from === "sensei-flow" && msg.taskId) {
    getToken().then((t) => { if (t) postResult(t, msg.taskId, msg.event, msg.data || {}); });
    try { sendResponse({ ok: true }); } catch (e) {}
    return true;
  }
  if (msg && msg.type === "STATUS") {
    (async () => {
      sendResponse({
        bridge: await bridgeUp(),
        paired: !!(await getToken()),
        loggedIn: await isLoggedIn(),
        account: await detectAccount(),
        extId: await getExtId(),
      });
    })();
    return true;
  }
  if (msg && msg.type === "UNPAIR") {
    _token = null;
    chrome.storage.local.remove("token").then(() => sendResponse({ ok: true }));
    return true;
  }
  
  
  if (msg && msg.type === "OVERLAY_STATUS") {
    sendResponse({ active: (Date.now() - _lastMintAt) < 25000, tokenCount: _tokenCount });
    return true;
  }
  return false;
});
