




window.addEventListener("message", (e) => {
  if (e.source !== window) return;
  const d = e.data;
  if (!d) return;
  
  if (d.from === "sensei-flow" && d.taskId && d.event) {
    try { chrome.runtime.sendMessage(d, () => void chrome.runtime.lastError); } catch (err) {}
    return;
  }
  
  if (d.from === "sensei-action" && d.action) {
    try {
      chrome.storage.local.set({ flowAction: d.action, flowActionSiteKey: d.siteKey || "" });
    } catch (err) {}
  }
});



(() => {
  let ov = null;

  function build() {
    if (ov) return ov;
    ov = document.createElement("div");
    ov.id = "sensei-working-overlay";
    Object.assign(ov.style, {
      position: "fixed", inset: "0", zIndex: 2147483646, display: "none",
      alignItems: "center", justifyContent: "center",
      background: "rgba(8,9,18,0.66)", backdropFilter: "blur(7px)",
      webkitBackdropFilter: "blur(7px)",
      fontFamily: "'Segoe UI Variable Display','Segoe UI',system-ui,sans-serif",
    });
    
    ov.innerHTML = `
      <style>
        @keyframes sensei-glow {
          0%,100% { text-shadow: 0 0 12px rgba(192,38,211,.55), 0 0 30px rgba(168,85,247,.35); }
          50%     { text-shadow: 0 0 22px rgba(216,80,255,.95), 0 0 52px rgba(168,85,247,.6); }
        }
      </style>
      <div style="padding:30px 60px;border-radius:46px;text-align:center;
                  background:radial-gradient(130% 150% at 50% 25%, rgba(80,30,160,.92), rgba(24,14,48,.92));
                  box-shadow:0 24px 80px rgba(88,28,135,.55), inset 0 0 0 1px rgba(168,85,247,.22);">
        <div style="font-size:40px;font-weight:800;letter-spacing:.5px;color:#d84dff;
                    animation:sensei-glow 1.8s ease-in-out infinite;">Microstock Sensei</div>
        <div style="margin-top:4px;font-size:15px;font-weight:500;letter-spacing:1px;color:#c4b5fd;">
          is working, leave this open</div>
      </div>`;
    (document.body || document.documentElement).appendChild(ov);
    return ov;
  }

  function tick() {
    try {
      chrome.runtime.sendMessage({ type: "OVERLAY_STATUS" }, (st) => {
        if (chrome.runtime.lastError || !st) return;
        build().style.display = (st && st.active) ? "flex" : "none";
      });
    } catch (e) {}
  }
  tick();
  setInterval(tick, 1500);
})();
