








(async () => {
  const spec = window.__senseiFlowSpec || {};
  const taskId = spec.taskId || "";
  const post = (event, data) => {
    try { window.postMessage({ from: "sensei-flow", taskId, event, data: data || {} }, "*"); }
    catch (e) {}
  };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  
  const SLATE = "[data-slate-editor]";
  const MEDIA = 'img[src*="trpc/media"], img[src*="/fx/api/"]';
  const CREATE = ["Criar", "Create", "Erstellen", "Créer", "Crear"];
  const NEW_PROJECT = ["Novo projeto", "New project", "Neues Projekt", "Nouveau projet",
                       "Nuevo proyecto", "Nuovo progetto"];
  const ASPECT_SUFFIX = { "16:9": "LANDSCAPE", "4:3": "LANDSCAPE_4_3", "1:1": "SQUARE",
                          "3:4": "PORTRAIT_3_4", "9:16": "PORTRAIT" };
  const DAILY = ["limite diário de gerações", "atingiu o limite diário",
                 "daily limit", "reached your daily limit"];
  const UNUSUAL = ["atividade incomum", "unusual activity"];
  const POLICY = ["viola nossas políticas", "violar nossas políticas",
                  "violate our policies", "content policies"];

  const textIncludes = (needles) => {
    const body = (document.body.innerText || "").toLowerCase();
    return needles.some((n) => body.includes(n.toLowerCase()));
  };

  
  function killPromo() {
    const NEEDLES = ["welcome to google flow", "what's new", "what’s new",
                     "registros de alterações", "changelog", "bem-vindo ao google flow"];
    const editor = document.querySelector(SLATE);
    const hit = (el) => {
      const t = (el.innerText || "").toLowerCase();
      return NEEDLES.some((n) => t.includes(n));
    };
    const seen = new Set();
    const handle = (el) => {
      if (!el || seen.has(el)) return; seen.add(el);
      if (editor && el.contains(editor)) return;
      if (!hit(el)) return;
      const b = el.querySelector('button[aria-label*="close" i],button[aria-label*="fechar" i],'
        + 'button[aria-label*="dismiss" i],button[aria-label*="dispensar" i]');
      if (b) { try { b.click(); return; } catch (e) {} }
      el.style.display = "none"; el.style.pointerEvents = "none";
    };
    document.querySelectorAll('[role="dialog"],[aria-modal="true"]').forEach(handle);
  }
  async function dismissOverlays() {
    for (let i = 0; i < 2; i++) {
      try { document.dispatchEvent(new KeyboardEvent("keydown",
        { key: "Escape", keyCode: 27, which: 27, bubbles: true })); } catch (e) {}
      try { killPromo(); } catch (e) {}
      for (const s of ['button[aria-label*="Close" i]', 'button[aria-label*="Fechar" i]',
                       'button[aria-label*="Dismiss" i]', 'button[aria-label*="Dispensar" i]']) {
        const el = document.querySelector(s);
        if (el) { try { el.click(); } catch (e) {} }
      }
      await sleep(200);
    }
  }

  const editorReady = () => !!document.querySelector(SLATE);

  async function ensureEditor() {
    if (editorReady()) return true;
    
    const all = Array.from(document.querySelectorAll("button, a"));
    const btn = all.find((b) => {
      const t = (b.textContent || "").trim();
      return NEW_PROJECT.some((n) => t.toLowerCase().includes(n.toLowerCase()));
    });
    if (btn) { try { btn.click(); } catch (e) {} }
    const deadline = Date.now() + 20000;
    while (Date.now() < deadline) {
      await dismissOverlays();
      if (editorReady()) return true;
      await sleep(500);
    }
    return editorReady();
  }

  
  function agentButton() {
    return Array.from(document.querySelectorAll('button[aria-pressed]')).find((b) => {
      const t = (b.textContent || "").replace(/\s+/g, " ").trim();
      return /^(agente|agent)$/i.test(t);
    });
  }
  async function ensureAgentOff() {
    const el = agentButton();
    if (!el) return true;                       
    if (el.getAttribute("aria-pressed") !== "true") return true;
    try { el.click(); } catch (e) {}
    await sleep(300);
    const el2 = agentButton();
    return !el2 || el2.getAttribute("aria-pressed") !== "true";
  }

  
  function tabSelected(suffix) {
    const tab = document.querySelector(`button[role="tab"][id$="-trigger-${suffix}"]`);
    return tab ? (tab.getAttribute("aria-selected") === "true"
      || tab.getAttribute("data-state") === "active") : null;
  }
  async function pickTab(suffix) {
    for (let i = 0; i < 3; i++) {
      if (tabSelected(suffix) === true) return true;
      const tab = document.querySelector(`button[role="tab"][id$="-trigger-${suffix}"]`);
      if (tab) {
        const o = { bubbles: true, cancelable: true, view: window };
        try {
          tab.dispatchEvent(new MouseEvent("mousedown", o));
          tab.dispatchEvent(new MouseEvent("mouseup", o));
          tab.dispatchEvent(new MouseEvent("click", o));
        } catch (e) {}
      }
      await sleep(350);
    }
    return tabSelected(suffix) === true;
  }
  async function setOptions(aspect, perGen) {
    const suf = aspect ? ASPECT_SUFFIX[aspect] : null;
    if (suf) {
      const deadline = Date.now() + 6000;
      while (Date.now() < deadline &&
             !document.querySelector(`button[role="tab"][id$="-trigger-${suf}"]`)) await sleep(400);
      await pickTab(suf);
    }
    const qty = String(perGen || "").replace(/\D/g, "");
    if (qty && qty !== "0") await pickTab(qty);
  }

  
  function createBtn() {
    const btns = Array.from(document.querySelectorAll("button")).filter((b) => {
      const r = b.getBoundingClientRect(); return r.width > 0 && r.height > 0;
    });
    return btns.find((b) => /arrow_forward|arrow_upward/i.test(b.textContent || "")
        && /criar|create|enviar|send/i.test(b.textContent || ""))
      || btns.find((b) => /criar|create|enviar|send/i.test(
        (b.getAttribute("aria-label") || "") + " " + (b.textContent || "")))
      || null;
  }
  
  const createReady = () => {
    const b = createBtn();
    return !!b && b.getAttribute("aria-disabled") !== "true" && !b.disabled;
  };

  
  
  
  
  
  async function insertPrompt(text) {
    const editor = document.querySelector(SLATE);
    if (!editor) return false;
    const want = (text || "").trim();
    const selectAll = () => {
      try {
        const r = document.createRange(); r.selectNodeContents(editor); r.collapse(false);
        const s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
      } catch (e) {}
    };
    const ok = () => {
      const cur = (editor.innerText || "").trim();
      return (!want || cur.includes(want)) && createReady();
    };

    
    editor.focus(); selectAll();
    try {
      const dt = new DataTransfer(); dt.setData("text/plain", text);
      editor.dispatchEvent(new ClipboardEvent("paste",
        { clipboardData: dt, bubbles: true, cancelable: true }));
    } catch (e) {}
    await sleep(300);
    if (ok()) return true;

    
    editor.focus(); selectAll();
    try {
      const bev = new InputEvent("beforeinput",
        { bubbles: true, cancelable: true, inputType: "insertText", data: text });
      bev.getTargetRanges = () => {
        const s = window.getSelection();
        return s && s.rangeCount > 0 ? [s.getRangeAt(0)] : [];
      };
      editor.dispatchEvent(bev);
      editor.dispatchEvent(new InputEvent("input",
        { bubbles: true, inputType: "insertText", data: text }));
    } catch (e) {}
    await sleep(300);
    if (ok()) return true;

    
    editor.focus(); selectAll();
    try { document.execCommand("insertText", false, text); } catch (e) {}
    await sleep(300);
    if (ok()) return true;

    
    const cur = (editor.innerText || "").trim();
    return want ? cur.includes(want) : true;
  }

  
  async function clickCreate() {
    let b = createBtn();
    if (!b) {
      
      const ed = document.querySelector(SLATE);
      const all = Array.from(document.querySelectorAll("button")).filter((x) => {
        const r = x.getBoundingClientRect(); return r.width > 0 && r.height > 0 && !x.disabled;
      });
      if (ed) {
        const er = ed.getBoundingClientRect();
        let bestX = -1;
        for (const x of all) {
          const r = x.getBoundingClientRect(); const cy = r.top + r.height / 2;
          if (cy >= er.top - 80 && cy <= er.bottom + 80 && r.x > bestX) { b = x; bestX = r.x; }
        }
      }
    }
    if (!b) throw new Error("Botão de enviar (Criar) não encontrado.");
    
    const o = { bubbles: true, cancelable: true, view: window };
    try {
      b.dispatchEvent(new MouseEvent("mousedown", o));
      b.dispatchEvent(new MouseEvent("mouseup", o));
      b.click();
    } catch (e) {
      try { b.click(); } catch (e2) {}
    }
  }

  
  const mediaSrcs = () => Array.from(new Set(
    Array.from(document.querySelectorAll(MEDIA)).map((e) => e.src).filter(Boolean)));
  const newSrcs = (known) => mediaSrcs().filter((s) => !known.includes(s));

  async function waitNewImages(known, expected, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    const pauseGrace = Date.now() + 30000;
    const policyGrace = Date.now() + 8000;
    while (Date.now() < deadline) {
      let nw = newSrcs(known);
      if (nw.length) {
        for (let i = 0; i < 8; i++) {           
          await sleep(1500);
          const more = newSrcs(known);
          nw = more;
          if (more.length >= expected) break;
        }
        return nw;
      }
      if (Date.now() >= policyGrace && textIncludes(POLICY)) { const e = new Error("policy"); e.reason = "policy"; throw e; }
      if (Date.now() >= pauseGrace) {
        if (textIncludes(DAILY)) { const e = new Error("daily_limit"); e.reason = "daily_limit"; throw e; }
        if (textIncludes(UNUSUAL)) { const e = new Error("unusual_activity"); e.reason = "unusual_activity"; throw e; }
      }
      await sleep(1000);
    }
    const e = new Error("timeout"); e.reason = "timeout"; throw e;
  }

  
  function blobToB64(blob) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(String(r.result).split(",")[1] || "");
      r.onerror = rej;
      r.readAsDataURL(blob);
    });
  }
  async function fetchImageB64(src) {
    const r = await fetch(src, { credentials: "include" });
    if (!r.ok) throw new Error("fetch " + r.status);
    const blob = await r.blob();
    return { b64: await blobToB64(blob), contentType: blob.type || "", bytes: blob.size };
  }

  
  try {
    post("started", { url: location.href });
    await dismissOverlays();
    if (!editorReady()) await ensureEditor();
    if (!editorReady()) { post("error", { message: "Editor do Flow não encontrado (abra um projeto).", reason: "no_editor" }); return; }
    await ensureAgentOff();
    try { await setOptions(spec.aspect, spec.perGen); } catch (e) {}
    const known = mediaSrcs();
    if (!(await insertPrompt(spec.prompt))) { post("error", { message: "Falha ao inserir o prompt.", reason: "insert" }); return; }
    await clickCreate();
    post("generating", {});
    const expected = parseInt(String(spec.perGen || "1").replace(/\D/g, "")) || 1;
    let imgs;
    try { imgs = await waitNewImages(known, expected, spec.timeoutMs); }
    catch (e) { post("error", { message: String(e.message || e), reason: e.reason || "wait" }); return; }
    let i = 0;
    for (const src of imgs) {
      i++;
      try {
        const img = await fetchImageB64(src);
        post("image", { index: i, total: imgs.length, src, b64: img.b64, contentType: img.contentType, bytes: img.bytes });
      } catch (e) {
        post("image_error", { index: i, src, message: String(e) });
      }
    }
    post("done", { count: imgs.length });
  } catch (e) {
    post("error", { message: String((e && e.message) || e), reason: "fatal" });
  }
})();
