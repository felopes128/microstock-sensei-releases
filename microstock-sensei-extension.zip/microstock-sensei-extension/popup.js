const $ = (id) => document.getElementById(id);

function state(st) {
  if (!st || !st.bridge) return { k: "off", ic: "!", w: "Abra o app",
    h: "Abra o Microstock Sensei no computador — a extensão conecta sozinha." };
  if (!st.paired) return { k: "wait", ic: "⋯", w: "Conectando…",
    h: "Pareando com o app… só um instante." };
  if (!st.loggedIn) return { k: "wait", ic: "⋯", w: "Falta login",
    h: "Entre no Google Flow neste Chrome para liberar a geração." };
  return { k: "ready", ic: "✓", w: "Pronto para gerar",
    h: "Tudo certo. Mantenha este Chrome aberto enquanto o app gera." };
}

function render(st) {
  const s = state(st);
  $("emblem").className = "emblem " + s.k;
  $("emicon").textContent = s.ic;
  $("word").className = "word " + s.k;
  $("word").textContent = s.w;
  $("acct").textContent = (st && st.loggedIn && st.account) ? st.account : "";
  $("hint").textContent = s.h;
}

function refresh() {
  try {
    chrome.runtime.sendMessage({ type: "STATUS" }, (st) => {
      render((chrome.runtime.lastError || !st) ? null : st);
    });
  } catch (e) { render(null); }
}

$("btnReconnect").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "UNPAIR" }, () => setTimeout(refresh, 400));
});

try { $("brandVer").textContent = "v" + chrome.runtime.getManifest().version; } catch (e) {}
refresh();
setInterval(refresh, 2000);
